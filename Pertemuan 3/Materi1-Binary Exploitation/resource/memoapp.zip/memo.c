#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

void mainMenu()
{
    printf("Selamat Datang di MemoKeep\n");
    printf("==================================\n");
    printf("1. Buat Memo\n2. Lihat Memo\n3. Keluar\n> ");
}

void buatMemo(char memo[])
{
    printf("Masukkan memo kamu: ");
    scanf("%s", memo);
    // Memo kamu akan disimpan dialat ini loh, jangan sampai lupa loh!
    printf("Memo berhasil disimpan dialamat ini: %p\n", memo);
}

void lihatMemo()
{
    int64_t p;
    // Masukin alamat yang kamu dapatkan tadi!
    printf("Pilih lokasi dari alamat memo: ");
    scanf("%llx", &p);
    char *x = (char *)p;
    printf("%s\n", x);
}

char flag[64];

int main(int argc, char const *argv[])
{
    setvbuf(stdout, NULL, _IONBF, 0);
    // Disini, kamu bisa dapetin flag juga loh!
    FILE *fp = fopen("flag.txt", "r");
    fgets(flag, 40, fp);
    char memoku[3600];

    int i;
    for (i = 0; i < 3; i++)
    {
        mainMenu();
        int pilihan;
        scanf("%d", &pilihan);
        switch (pilihan)
        {
        case 1:
            buatMemo(memoku);
            break;
        case 2:
            lihatMemo();
            break;
        default:
            break;
        }
    }
}
