#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int vuln() {
    char buf[32];

    printf("Mau kemana kita: ");
    gets(buf);

    int coba = 0;
    for (int i = 0; buf[i]; i++) {
        coba &= buf[i] ^ buf[i];
    }

    return coba;
}

int main(char argc, char** argv) {
    setresuid(getegid(), getegid(), getegid());
    setresgid(getegid(), getegid(), getegid());
    setbuf(stdout, NULL);

    if (vuln()) {
        puts("Kebetulan aku juga mau kesana!");
        puts("Karena tujuan kita sama, Nih aku kasih akses ke flag gratis");
        
        system("cat flag.txt");
    } else {
        puts("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
    }
}